/** Persisted current-user device authorization state. */
export interface PendingUserAuthorization {
    /** Opaque device code returned by the official CLI. */
    readonly deviceCode: string;
    /** Exact user scopes requested when the device code was created. */
    readonly scopes: readonly string[];
}
/** Serialize a pending authorization for credential storage. */
export declare function encodePendingUserAuthorization(deviceCode: string, scopes: readonly string[]): string;
/** Decode a pending authorization only when it matches the current scope set. */
export declare function decodePendingUserAuthorization(value: string, currentScopes: readonly string[]): PendingUserAuthorization | undefined;
//# sourceMappingURL=pending-user-auth.d.ts.map
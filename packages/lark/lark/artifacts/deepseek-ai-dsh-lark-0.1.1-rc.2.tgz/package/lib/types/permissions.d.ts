/** Lark capability groups and their importable permission template. */
/** Stable capability identifier rendered by the management page. */
export type LarkCapabilityId = 'calendar' | 'im' | 'docs' | 'drive' | 'markdown' | 'base' | 'sheets' | 'slides' | 'task' | 'wiki' | 'contact' | 'mail' | 'meeting' | 'attendance' | 'approval' | 'okr' | 'apps';
/** Required application and user scopes for one capability group. */
export interface LarkCapabilityDefinition {
    /** Stable identifier. */
    readonly id: LarkCapabilityId;
    /** Chinese product label. */
    readonly label: string;
    /** Application scopes imported under the tenant token type. */
    readonly tenant: readonly string[];
    /** Scopes imported under the user token type and requested during OAuth. */
    readonly user: readonly string[];
}
/** Enabled application scopes split by the token types reported by Open Platform. */
export interface LarkApplicationScopeSets {
    /** Scopes enabled for tenant access tokens. */
    readonly tenant: ReadonlySet<string>;
    /** Scopes enabled for user access tokens. */
    readonly user: ReadonlySet<string>;
}
/** Tenant scopes required by the private-chat transport. */
export declare const LARK_CONVERSATION_TENANT_SCOPES: readonly ["im:message.p2p_msg:readonly", "im:message:send_as_bot", "im:resource"];
/** Event subscriptions required by the private-chat transport. */
export declare const LARK_CONVERSATION_EVENTS: readonly ["im.message.receive_v1"];
/**
 * Parse the official CLI raw application-info success envelope.
 * @param value - JSON emitted by `lark-cli api GET application/v6/applications/:app_id`.
 * @returns Enabled tenant and user scope sets.
 */
export declare function applicationScopeSets(value: unknown): LarkApplicationScopeSets;
/** Minimum scopes for the Lark CLI capabilities exposed by this bundle. */
export declare const LARK_CAPABILITIES: readonly LarkCapabilityDefinition[];
/** Import payload accepted by the Feishu/Lark permission batch-import dialog. */
export declare function permissionImportTemplate(): string;
/** Complete tenant-scope set requested by managed registration and the import template. */
export declare function requestedTenantScopes(): string[];
/** Complete user-scope set requested by the management page's OAuth flow. */
export declare function requestedUserScopes(): string[];
//# sourceMappingURL=permissions.d.ts.map
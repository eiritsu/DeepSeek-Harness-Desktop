/** Lark private-chat transport between normalized Channel messages and durable DSH Agents. */
import type { Context } from '@deepseek-ai/cordis';
import { SessionId } from '@deepseek-ai/dsh-session';
import type { LarkChannel } from '@larksuite/channel';
declare module '@deepseek-ai/dsh-llm/message' {
    interface MessageSourceMap {
        /** Human input received from one Lark application and chat. */
        lark: {
            kind: 'lark';
            appId: string;
            chatId: string;
            messageId: string;
            senderId: string;
        };
    }
}
/** Construction options for one application-scoped Lark conversation bridge. */
export interface LarkConversationOptions {
    /** Application identity included in durable message provenance and session ids. */
    readonly appId: string;
    /** Only this Lark user may open private-chat turns. */
    readonly allowedSenderId: string;
    /** Maximum time to wait for the turn containing an accepted Lark message. */
    readonly responseTimeoutMs: number;
    /** Workspace used by newly created chat sessions. */
    readonly cwd: string;
    /** IANA time zone used when Lark supplies no browser time-zone provenance. */
    readonly timeZone: string;
}
/** Derive a stable opaque DSH identity without retaining the Lark chat id in filenames. */
export declare function larkSessionId(appId: string, chatId: string): SessionId;
/** Owns one Channel connection and every Agent lifecycle created for its private chats. */
export declare class LarkConversationBridge {
    private readonly ctx;
    private readonly channel;
    private readonly options;
    private readonly abort;
    private readonly creations;
    private readonly handles;
    private readonly liveTimeContexts;
    private readonly inFlight;
    private unsubscribers;
    private connected;
    /** Bind a connected official Channel to DSH Agent and attachment services. */
    constructor(ctx: Context, channel: LarkChannel, options: LarkConversationOptions);
    /** Attach handlers and complete the first WebSocket handshake. */
    connect(): Promise<void>;
    /** Stop ingress, settle active handlers, disconnect transport, and release owned Agents. */
    dispose(): Promise<void>;
    private handleMessage;
    private wasAccepted;
    private inboundContent;
    private downloadResource;
    private waitForTurn;
    private sendResponse;
    private ensureAgent;
    private createOrResumeAgent;
    /** Add Lark-owned context and Workspace membership to an Agent resumed by another client. */
    private configureLiveAgent;
    /** Configure a live session whose durable Lark provenance belongs to this application. */
    private configureDiscoveredAgent;
    /** Resolve the configured directory to one durable, user-renamable Workspace. */
    private resolveWorkspace;
}
//# sourceMappingURL=conversation.d.ts.map
/**
 * Read the usable current-user Open ID from an official CLI auth response.
 *
 * @param status Parsed `lark-cli auth status --json` output.
 * @returns The authorized user's Open ID, or `undefined` when that identity is unavailable.
 */
export declare function authenticatedUserOpenId(status: unknown): string | undefined;
/**
 * Compare an official CLI user identity with the scopes required by this plugin.
 *
 * @param status Parsed `lark-cli auth status --json` output.
 * @param requiredScopes User scopes requested by the current plugin version.
 * @returns Required scopes absent from the current user token.
 */
export declare function missingUserAuthorizationScopes(status: unknown, requiredScopes: readonly string[]): string[];
//# sourceMappingURL=auth-status.d.ts.map
/** Read-only classification helpers for official Lark CLI commands. */
/** Normalize deprecated model-facing command names to official CLI commands. */
export declare function normalizeLarkCommand(args: readonly string[]): string[];
/** Return whether a command is intrinsically read-only without CLI metadata lookup. */
export declare function isDirectReadOnlyCommand(args: readonly string[]): boolean;
/** Build a side-effect-free help invocation for the dispatched command path. */
export declare function commandHelpArguments(args: readonly string[]): string[] | undefined;
/** Return whether official CLI help declares the command read-only. */
export declare function helpDeclaresReadOnly(stdout: string, stderr: string): boolean;
//# sourceMappingURL=command-risk.d.ts.map
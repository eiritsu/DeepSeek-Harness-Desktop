/** Host integration for Lark/Feishu credentials, permissions, OAuth, and CLI tools. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { LarkCapabilityId } from './permissions.ts';
export type { LarkCapabilityDefinition, LarkCapabilityId } from './permissions.ts';
export { applicationScopeSets, LARK_CAPABILITIES, permissionImportTemplate, requestedUserScopes } from './permissions.ts';
/** Credential reference managed by the Lark Settings page. */
export declare const LARK_APP_SECRET_REF: import("@deepseek-ai/dsh-credentials").CredentialRef;
/** Settings namespace bound by the browser plugin. */
export declare const LARK_SETTINGS_NAMESPACE: import("@deepseek-ai/dsh-settings").SettingsNamespace;
/** Lark integration configuration and user-editable settings. */
export interface Config {
    /** Self-built application id. */
    appId?: string;
    /** Product endpoint family. */
    brand?: 'feishu' | 'lark';
    /** Credential reference containing the application secret. */
    appSecretEnv?: string;
    /** Maximum duration of one CLI operation. */
    cliTimeoutMs?: number;
    /** Per-stream in-memory CLI output limit. */
    maxOutputBytes?: number;
    /** Private official-CLI state directory below the Harness home. */
    cliConfigDir?: string;
    /** Credential setup mode selected by the management page. */
    credentialMode?: 'none' | 'managed' | 'self-built';
    /** Maximum duration of official managed-app registration. */
    registrationTimeoutMs?: number;
}
/** Schemastery configuration for the Lark integration. */
export declare const Config: z<Config>;
/** Application values accepted from the management page. */
export interface LarkApplicationInput {
    /** Self-built application id. */
    readonly appId: string;
    /** Product endpoint family. */
    readonly brand: 'feishu' | 'lark';
    /** Optional replacement secret; omission preserves the current secret. */
    readonly appSecret?: string;
}
/** One identity reported by the official CLI. */
export interface LarkIdentityStatus {
    /** CLI identity state. */
    readonly status: string;
    /** Whether the identity can currently be used. */
    readonly available: boolean;
    /** Server verification result, when verification ran. */
    readonly verified?: boolean;
}
/** Permission outcome for one management-page capability row. */
export interface LarkCapabilityStatus {
    /** Stable capability id. */
    readonly id: LarkCapabilityId;
    /** Chinese label. */
    readonly label: string;
    /** Whether every required tenant and user scope is enabled for the application. */
    readonly state: 'granted' | 'missing' | 'unknown';
    /** Required scopes not reported by the application. */
    readonly missingScopes: readonly string[];
}
/** Complete safe-to-display Lark management snapshot. */
export interface LarkManagementStatus {
    /** Configured application id. */
    readonly appId: string;
    /** Product endpoint family. */
    readonly brand: 'feishu' | 'lark';
    /** Source of the application credentials used by the official CLI. */
    readonly credentialMode: 'none' | 'managed' | 'self-built';
    /** Whether the application secret resolves. */
    readonly secretConfigured: boolean;
    /** Whether the current credential source accepts a replacement. */
    readonly secretWritable: boolean;
    /** Whether the official CLI produced a status response. */
    readonly cliAvailable: boolean;
    /** Bot/tenant identity state. */
    readonly bot: LarkIdentityStatus;
    /** User OAuth identity state. */
    readonly user: LarkIdentityStatus;
    /** Permission rows in product order. */
    readonly capabilities: readonly LarkCapabilityStatus[];
    /** Batch-import JSON copied by the page without rendering it. */
    readonly permissionTemplate: string;
    /** Non-secret diagnostic from the latest inspection failure. */
    readonly diagnostic?: string;
}
/** Device authorization values returned by the official CLI. */
export interface LarkUserAuthRequest {
    /** Opaque verification URL opened by the browser. */
    readonly verificationUrl: string;
    /** Opaque code used to complete polling after user consent. */
    readonly deviceCode: string;
}
/** Browser handoff for official managed PersonalAgent registration. */
export interface LarkManagedRegistrationRequest {
    /** Opaque official registration URL opened by the browser. */
    readonly verificationUrl: string;
}
/** Canonical result of one official CLI invocation. */
export interface LarkCliResult {
    /** Exit code, or null when terminated by a signal. */
    readonly exitCode: number | null;
    /** Terminating signal, or null on normal exit. */
    readonly signal: string | null;
    /** Whether the plugin-owned deadline fired. */
    readonly timedOut: boolean;
    /** Captured stdout tail. */
    readonly stdout: string;
    /** Captured stderr tail. */
    readonly stderr: string;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Lark/Feishu management Remote service. */
        larkManagement: LarkManagementGateway;
    }
}
/** Remote service and model-facing tool backed by the official Lark CLI. */
export default class LarkManagementGateway extends TypertRemoteService {
    static inject: string[];
    private readonly settings;
    private pendingRegistration;
    /** Register the Remote service, settings namespace, tool, and write-approval gate. */
    constructor(ctx: Context, config: Config);
    /** Read credentials, application scopes, and bot/user identity without exposing secret values. */
    status(): Promise<LarkManagementStatus>;
    /** Store the application id/brand and optionally replace the write-only secret. */
    saveApplication(input: LarkApplicationInput): Promise<void>;
    /** Remove the provider-managed application secret. */
    clearSecret(): Promise<void>;
    /** Start the official PersonalAgent app-registration flow without requesting a manual secret. */
    beginManagedRegistration(brand: 'feishu' | 'lark'): Promise<LarkManagedRegistrationRequest>;
    /** Finish a managed app registration after the user approves the official browser prompt. */
    completeManagedRegistration(): Promise<void>;
    /** Start user OAuth for the capability scopes represented by the management page. */
    beginUserAuth(): Promise<LarkUserAuthRequest>;
    /** Complete a previously started user OAuth request after the user authorizes it. */
    completeUserAuth(deviceCode: string): Promise<void>;
    private resolvedConfig;
    private capabilityStatus;
    private runJson;
    private runCli;
    private spawnCli;
    private collectCli;
    private waitForRegistrationUrl;
    private registerTool;
}
//# sourceMappingURL=index.d.ts.map